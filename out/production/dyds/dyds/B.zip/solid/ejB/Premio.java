package dyds.solid.ejB;

public interface Premio {

    String mensajeAviso();
}
