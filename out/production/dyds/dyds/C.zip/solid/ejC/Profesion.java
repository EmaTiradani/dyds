package dyds.solid.ejC;

public enum Profesion{
    NONE,
    Granuja,
    Mago,
    Campeon
}
