package dyds.solid.ejA;

public interface RedSocial {
    void postearContenido(Contenido contenido);
}
